# Aegon TikTok Generator

Convierte imágenes de producto en vídeos verticales (1080x1920) listos para
TikTok/Reels con:
- Efecto Ken Burns (zoom/pan suave) en cada imagen
- Transición en crossfade entre imágenes
- Overlay de texto estilo Aegon (dorado, gradiente inferior, serif + sans)
- Música de fondo opcional con fade in/out

## 1. Subir a GitHub

```bash
git init
git add .
git commit -m "Aegon TikTok generator"
git branch -M main
git remote add origin https://github.com/aegonwatches/tiktok-generator.git
git push -u origin main
```

## 2. Instalar (local o en un runner de GitHub Actions)

```bash
sudo apt-get install -y ffmpeg
pip install -r requirements.txt
```

## 3. (Opcional pero recomendado) Añadir las tipografías reales de marca

Descarga `Cormorant Garamond` y `Jost` desde Google Fonts y coloca los `.ttf`
en la carpeta `fonts/` con estos nombres exactos:

```
fonts/CormorantGaramond-SemiBold.ttf
fonts/Jost-Medium.ttf
```

Si no los añades, el script usa una fuente serif del sistema como respaldo
(el vídeo se genera igual, solo cambia la tipografía).

## 4. Generar un vídeo

```bash
python make_tiktok.py \
  --images ./sample_images \
  --output ./out/skeleton.mp4 \
  --title "SKELETON" \
  --price "89€" \
  --cta "DM PARA COMPRAR"
```

Con música de fondo:

```bash
python make_tiktok.py \
  --images ./product_photos/skeleton \
  --output ./out/skeleton.mp4 \
  --title "SKELETON" \
  --price "89€" \
  --cta "DM PARA COMPRAR" \
  --music ./music/track.mp3
```

## Parámetros

| Flag | Descripción | Default |
|---|---|---|
| `--images` | Carpeta con imágenes jpg/png/webp | requerido |
| `--output` | Ruta del mp4 de salida | requerido |
| `--title` | Nombre del modelo (SKELETON, MESH, WOOD) | requerido |
| `--price` | Precio a mostrar | requerido |
| `--cta` | Texto del botón de llamada a la acción | `DM PARA COMPRAR` |
| `--watermark` | Texto de marca arriba | `AEGON` |
| `--music` | Ruta a mp3/wav de fondo | ninguno |
| `--seconds-per-image` | Duración de cada imagen | `2.6` |
| `--crossfade` | Duración de la transición | `0.5` |

## Notas

- Las imágenes se recortan automáticamente en modo "cover" al formato 9:16 —
  no hace falta editarlas antes, pero **sí recuerda quitar cualquier logo de
  terceros** (Winner, BOBO BIRD) con Canva antes de meterlas aquí.
- Este script NO genera imágenes con IA ni sube nada a TikTok — solo compone
  el vídeo final a partir de fotos reales del producto. Sigue tu flujo:
  producto real → aquí para el montaje → subida manual a TikTok/Facebook.
- Automatización futura: se puede envolver este script en un GitHub Action
  que corra cada vez que subas imágenes nuevas a una carpeta del repo, y deje
  el mp4 listo como artifact descargable. Dilo si quieres que te lo monte.
